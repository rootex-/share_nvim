import treesitter from 'eslint-config-treesitter';

export default [
  ...treesitter,
];
