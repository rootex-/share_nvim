//> using scala 3.1.0
//  ^keyword
//        ^parameter
//              ^string

/*
 * Beep boop
 */
// <- comment

// Single line comment
// <- comment
