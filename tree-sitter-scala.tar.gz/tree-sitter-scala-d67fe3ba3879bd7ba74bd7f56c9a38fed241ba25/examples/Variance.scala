class Function1[-T1, +R]
